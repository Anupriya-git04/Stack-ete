// script.js
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('registration-form');
    const submitButton = document.getElementById('submit-button');

    // Helper functions
    const validateFullName = (value) => /^[A-Za-z\s]{3,}$/.test(value);
    const validateEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    const validatePassword = (value) => /^(?=.*[a-zA-Z])(?=.*\d)[A-Za-z\d]{8,}$/.test(value);
    const validateDateOfBirth = (value) => {
        const date = new Date(value);
        const age = new Date().getFullYear() - date.getFullYear();
        return age >= 18;
    };

    const checkFullName = () => {
        const input = document.getElementById('full-name');
        const error = document.getElementById('full-name-error');
        const feedback = document.getElementById('full-name-feedback');
        if (validateFullName(input.value)) {
            input.classList.add('valid');
            input.classList.remove('invalid');
            error.textContent = '';
            feedback.innerHTML = '✔️';
        } else {
            input.classList.add('invalid');
            input.classList.remove('valid');
            error.textContent = 'Invalid name. Only letters and spaces allowed, minimum 3 characters.';
            feedback.innerHTML = '❌';
        }
    };

    const checkEmail = () => {
        const input = document.getElementById('email');
        const error = document.getElementById('email-error');
        const feedback = document.getElementById('email-feedback');
        if (validateEmail(input.value)) {
            input.classList.add('valid');
            input.classList.remove('invalid');
            error.textContent = '';
            feedback.innerHTML = '✔️';
        } else {
            input.classList.add('invalid');
            input.classList.remove('valid');
            error.textContent = 'Invalid email format.';
            feedback.innerHTML = '❌';
        }
    };

    const checkPassword = () => {
        const input = document.getElementById('password');
        const error = document.getElementById('password-error');
        const feedback = document.getElementById('password-feedback');
        if (validatePassword(input.value)) {
            input.classList.add('valid');
            input.classList.remove('invalid');
            error.textContent = '';
            feedback.innerHTML = '✔️';
        } else {
            input.classList.add('invalid');
            input.classList.remove('valid');
            error.textContent = 'Password must be at least 8 characters long, with letters and numbers.';
            feedback.innerHTML = '❌';
        }
    };

    const checkConfirmPassword = () => {
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        const error = document.getElementById('confirm-password-error');
        const feedback = document.getElementById('confirm-password-feedback');
        if (password === confirmPassword) {
            document.getElementById('confirm-password').classList.add('valid');
            document.getElementById('confirm-password').classList.remove('invalid');
            error.textContent = '';
            feedback.innerHTML = '✔️';
        } else {
            document.getElementById('confirm-password').classList.add('invalid');
            document.getElementById('confirm-password').classList.remove('valid');
            error.textContent = 'Passwords do not match.';
            feedback.innerHTML = '❌';
        }
    };

    const checkDateOfBirth = () => {
        const input = document.getElementById('dob');
        const error = document.getElementById('dob-error');
        const feedback = document.getElementById('dob-feedback');
        if (validateDateOfBirth(input.value)) {
            input.classList.add('valid');
            input.classList.remove('invalid');
            error.textContent = '';
            feedback.innerHTML = '✔️';
            submitButton.disabled = false;
        } else {
            input.classList.add('invalid');
            input.classList.remove('valid');
            error.textContent = 'You must be at least 18 years old.';
            feedback.innerHTML = '❌';
            submitButton.disabled = true;
        }
    };

    // Attach event listeners
    document.getElementById('full-name').addEventListener('input', checkFullName);
    document.getElementById('email').addEventListener('input', checkEmail);
    document.getElementById('password').addEventListener('input', checkPassword);
    document.getElementById('confirm-password').addEventListener('input', checkConfirmPassword);
    document.getElementById('dob').addEventListener('change', checkDateOfBirth);

    form.addEventListener('submit', (event) => {
        checkFullName();
        checkEmail();
        checkPassword();
        checkConfirmPassword();
        checkDateOfBirth();

        // Prevent form submission if there are validation errors
        if (document.querySelectorAll('.invalid').length > 0) {
            event.preventDefault();
        }
    });
});
