let booklist = [];
let currentPage = 1;
const itemsPerPage = 3; // Show 3 courses per page

const fetchBooksBtn = document.querySelector('#fetchbooks');
const mainContainer = document.querySelector('#books-container');
const paginationContainer = document.querySelector('#pagination-container');
const searchingInput = document.querySelector('#search');
const sortingItem = document.querySelector('#sorting');

// Fetch books from JSON file and render them
fetchBooksBtn.addEventListener('click', () => {
  fetch('books.json') // Replace 'books.json' with the actual API URL if needed
    .then(response => response.json())
    .then(data => {
      booklist = data; // Assign fetched data to booklist
      displayBooks();
    })
    .catch(error => console.error('Error fetching books:', error));
});

// Display books based on current page, search and sort criteria
function displayBooks() {
  mainContainer.innerHTML = "";
  
  let filteredBooks = booklist.filter(book =>
    book.Title.toLowerCase().includes(searchingInput.value.toLowerCase())
  );

  // Sort books by title
  if (sortingItem.value === 'asc') {
    filteredBooks.sort((a, b) => a.Title.localeCompare(b.Title));
  } else {
    filteredBooks.sort((a, b) => b.Title.localeCompare(a.Title));
  }

  // Paginate books
  let paginatedBooks = filteredBooks.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  // Create book cards
  paginatedBooks.forEach(book => {
    let container = document.createElement('div');
    container.style.border = '1px solid #ddd';
    container.style.borderRadius = '8px';
    container.style.padding = '10px';
    container.style.margin = '5px';
    container.style.textAlign = 'left';
    container.style.backgroundColor = '#fff';

    let CourseId = document.createElement('div');
    CourseId.textContent = `CourseID: ${book.CourseId}`;
    CourseId.style.fontWeight = 'bold';

    let Title = document.createElement('div');
    Title.textContent = `Title: ${book.Title}`;

    let Instructor = document.createElement('div');
    Instructor.textContent = `Instructor: ${book.Instructor}`;

    let Duration = document.createElement('div');
    Duration.textContent = `Duration: ${book.Duration}`;

    let Rating = document.createElement('div');
    Rating.textContent = `Rating: ${book.Rating}`;

    let Price = document.createElement('div');
    Price.textContent = `Price: ${book.Price}`;

    let Enrolled = document.createElement('div');
    Enrolled.textContent = `Enrolled: ${book.Enrolled}`;

    container.appendChild(CourseId);
    container.appendChild(Title);
    container.appendChild(Instructor);
    container.appendChild(Duration);
    container.appendChild(Rating);
    container.appendChild(Price);
    container.appendChild(Enrolled);

    mainContainer.appendChild(container);
  });

  displayPagination(filteredBooks.length);
}

// Handle search input to filter books
searchingInput.addEventListener('input', () => {
  currentPage = 1; // Reset to first page on search
  displayBooks();
});

// Handle sorting change to sort books
sortingItem.addEventListener('change', () => {
  displayBooks();
});

// Display pagination controls based on total items
function displayPagination(totalItems) {
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  paginationContainer.innerHTML = "";

  for (let i = 1; i <= totalPages; i++) {
    let pageButton = document.createElement('button');
    pageButton.textContent = i;
    pageButton.style.margin = '5px';
    pageButton.style.padding = '10px 15px';
    pageButton.style.border = '1px solid #007bff';
    pageButton.style.backgroundColor = '#007bff';
    pageButton.style.color = 'white';
    pageButton.style.cursor = 'pointer';
    pageButton.style.borderRadius = '4px';
    
    if (i === currentPage) {
      pageButton.style.backgroundColor = '#28a745'; // Highlight the current page
      pageButton.style.borderColor = '#28a745';
    }

    pageButton.addEventListener('click', () => {
      currentPage = i;
      displayBooks();
    });

    paginationContainer.appendChild(pageButton);
  }
}